/**
 * 
 */
package com.example.transactionmanagement.common.exception;

/**
 * @author Nayeemul
 *
 */
public class RecordNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public RecordNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

	
	

}
