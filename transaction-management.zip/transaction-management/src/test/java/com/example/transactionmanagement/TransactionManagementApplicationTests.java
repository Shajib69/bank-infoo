package com.example.transactionmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransactionManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
